<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Budgetify</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="splash">
    <div class="splash-card">
        <div class="logo-bars">
            <span></span><span></span><span></span><span></span><span></span>
        </div>
        <h2>Budgetify<span>.</span></h2>
    </div>

    <div class="splash-loader">
        <span></span><span></span><span></span><span></span><span></span>
    </div>
</div>

<script>
    setTimeout(() => {
        window.location.href = "login.php";
    }, 2800);
</script>

</body>
</html>
